<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- Custom CSS -->
        <link rel="stylesheet" href="css/style.css">

        <!-- Boostrap -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    </head>

    <body>

    <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="aset/logo.png" alt="logo" width="52" height="54">
                </a>
                <p class ="ketlog mt-1">SMP AL IRSYAD AL ISLAMIYYAH <br>GORONTALO</p>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php">Login</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="menu.php">Menu </a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="form.php">Form</a>
                    </li>
                </ul>
                </div>
            </div>
        </nav> 

        <div class="container pendaftaran rounded-3 my-5 p-2 px-4">
            <div class="heading mt-3">
                <h2 class="text-center">Silahkan Mengisi Formulir Dibawah Ini</h2>
            </div>
            <form method="POST" action="aksi_crud.php" enctype="multipart/form-data" class="mt-5">
                <div class="row">
                    <h5 class="data-diri mb-3">Data Diri Siswa</h5>
                    <!-- NISN -->
                    <div class="mb-3">
                        <label for="exampleInputNisn" class="form-label">NISN</label>
                        <input type="text" class="form-control" name="nisn" id="nisn" required>
                    </div>
                    <!-- NAMA -->
                    <div class="mb-3">
                        <label for="exampleInputNama" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" name="nama_lengkap" id="nama_lengkap" required>
                    </div>
                    <!-- Tempat lahir -->
                    <div class="mb-3">
                        <label for="exampleInputTempat" class="form-label">Tempat</label>
                        <input type="text" class="form-control" name="tempat" id="tempat" required>
                    </div>
                    <!-- Tanggal Lahir -->
                    <div class=" col-lg-4 mb-3">
                        <label for="exampleInputTangal" class="form-label">Tanggal Lahir</label>
                        <input type="date" class="form-control" name="tanggal_lahir" id="tanggal_lahir" required>
                    </div>
                    <!-- Jenis kelamin -->
                    <div class="mb-3">
                        <label for="exampleInputJenisKelamin" class="form-label">Jenis Kelamin</label>
                        <input type="text" class="form-control" name="jenis_kelamin" id="jenis_kelamin" required>
                    </div>
                    <!-- Agama -->
                    <div class="mb-3">
                        <label for="exampleInputAgama" class="form-label">Agama</label>
                        <input type="text" class="form-control" name="agama" id="agama" required>
                    </div>
                    <!-- No HP -->
                    <div class="mb-3">
                        <label for="exampleInputHP" class="form-label">Nomor whatsapp</label>
                        <input type="text" class="form-control" name="nomor_handphone" id="nomor_handphone" required>
                    </div>
                    <!-- Alamat -->
                    <div class="mb-3">
                        <label for="exampleInputTangal" class="form-label">Alamat</label>
                        <textarea type="text" class="form-control" name="alamat" id="alamat" required></textarea>
                    </div>
                </div>

                <div class="row my-5">
                    <h5 class="data-ortu">Data Orangtua</h5>
                    <!-- Ayah -->
                    <div class="my-3">
                        <label for="exampleInputAyah" class="form-label">Nama Ayah</label>
                        <input type="text" class="form-control" name="ayah" id="ayah" required>
                    </div>
                    <!-- Pekerjaan Ayah -->
                    <div class="mb-3">
                        <label for="exampleInputPAyah" class="form-label">Pekerjaan Ayah</label>
                        <input type="text" class="form-control" name="pekerjaan_ayah" id="pekerjaan_ayah" required>
                    </div>
                    <!-- Ibu -->
                    <div class="mb-3">
                        <label for="exampleInputIbu" class="form-label">Nama Ibu</label>
                        <input type="text" class="form-control" name="ibu" id="ibu" required>
                    </div>
                    <!-- Pekerjaan Ibu -->
                    <div class="mb-3">
                        <label for="exampleInputPIbu" class="form-label">Pekerjaan Ibu</label>
                        <input type="text" class="form-control" name="pekerjaan_ibu" id="pekerjaan_ibu" required>
                    </div>
                </div>

                <div class="row mt-5">
                    <h3>Data Sekolah Sebelumnya</h3>
                    <!-- Asal Sekolah -->
                    <div class="my-3">
                        <label for="exampleInputSekolah" class="form-label">Asal Sekolah</label>
                        <input type="text" class="form-control" name="asal_sekolah" id="asal_sekolah" required>
                    </div>
                 

                <button type="submit" name="submit" class="btn mt-3 mb-5 btn-primary">Submit</button>
            </form>
        </div>
    </body>