<?php

// koneksi database
$server = "localhost";
$user = "root";
$password = "";
$database = "pendaftaran_siswa";

// koneksi
$koneksi = mysqli_connect($server, $user, $password, $database) or die(mysqli_error($koneksi));

// if (!$koneksi){
//     die("koneksi gagal".mysqli_error());
// }
// echo "koneksi sukses";
// // myslqi_close($koneksi);

?>