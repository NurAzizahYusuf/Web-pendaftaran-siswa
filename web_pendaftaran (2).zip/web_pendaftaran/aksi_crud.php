<?php
include "koneksi.php";

if(isset($_POST["login"]) ){

    $username = $_POST['email'];
    $password = $_POST['password'];

    $login = mysqli_query($koneksi, "SELECT * FROM login WHERE email = '$username' AND password = '$password'");

    if(mysqli_num_rows($login) == 0){
        echo "<script> alert('Email atau password salah!'); 
                document.location='index.php';
        </script>";
    }else{
        $_SESSION['admin'] = 1;
        header("Location: form.php");
    }
}



if(isset($_POST["submit"]) ){

    $nisn = htmlspecialchars($_POST["nisn"]);
    $nama = htmlspecialchars($_POST["nama_lengkap"]);
    $tempat = htmlspecialchars($_POST["tempat"]);
    $tanggal = htmlspecialchars($_POST["tanggal_lahir"]);
    $gender = htmlspecialchars($_POST["jenis_kelamin"]);
    $agama = htmlspecialchars($_POST["agama"]);
    $no_hp = htmlspecialchars($_POST["nomor_handphone"]);
    $alamat = htmlspecialchars($_POST["alamat"]);
    $ayah = htmlspecialchars($_POST["ayah"]);
    $p_ayah = htmlspecialchars($_POST["pekerjaan_ayah"]);
    $ibu = htmlspecialchars($_POST["ibu"]);
    $p_ibu = htmlspecialchars($_POST["pekerjaan_ibu"]);
    $sekolah = htmlspecialchars($_POST["asal_sekolah"]);
   

    $save = mysqli_query($koneksi, "INSERT INTO data_siswa(nisn,nama,tempat,tanggal_lahir,jenis_kelamin,agama,nomor_handphone,alamat,ayah,pekerjaan_ayah,ibu,pekerjaan_ibu,asal_sekolah) values('$nisn','$nama','$tempat','$tanggal','$gender','$agama','$no_hp','$alamat','$ayah','$p_ayah','$ibu','$p_ibu','$sekolah')");


    if($save){
        echo "<script>alert('Berhasil menginput berkas');
                    document.location='selesai.php';
            </script>";
    }else{
        echo "<script>alert('Input berkas gagal'); 
                    document.location='form.php';
            </script>";
    }




    // $fileraport = $_FILES['raport']['name'];
    // $ukuranraport = $_FILES['raport']['size'];
    // $error = $_FILES['raport']["error"];
    // $tmpname = $_FILES['raport']['tmp_name'];

    // $fileskhu = $_FILES['skhu']['name'];
    // $ukuranskhu = $_FILES['skhu']['size'];
    // $error = $_FILES['skhu']["error"];
    // $tmpname = $_FILES['raport']['tmp_name'];

    // $filefoto = $_FILES['foto']['name'];
    // $ukuranfoto = $_FILES['foto']['size'];
    // $error = $_FILES['foto']["error"];
    // $tmpname = $_FILES['raport']['tmp_name'];

    // if($error === 4 ){
    //     echo "<script> alert('Masukkan gambar'); 
    //         </script>";
    //     return false;
    // }



    // $jenisgambarvalid = ['jpg', 'jpeg'];
    // $jenisgambar = explode('.', $fileraport);
    // $ekstensi = strtolower(end($jenisgambar));
    // if(!in_array($ekstensi, $jenisgambarvalid)){
    //     echo "<script> alert('bukan gambar itu'); 
    //         </script>";
    //     return false;
    // }
    // if($ukuranraport > 1000000) {
    //     echo "<script> alert('terlalu besar, kompres mi dulu'); 
    //     </script>";
    //     return false;
    // }

    // move_uploaded_file($tmpname, 'img/' . $fileraport);

    // return $fileraport;



    // $jenisgambarvalid = ['jpg', 'jpeg'];
    // $jenisgambar = explode('.', $fileskhu);
    // $ekstensi = strtolower(end($jenisgambar));
    // if(!in_array($ekstensi, $jenisgambarvalid)){
    //     echo "<script> alert('bukan gambar itu'); 
    //         </script>";
    //     return false;
    // }
    // if($ukuranskhu > 1000000) {
    //     echo "<script> alert('terlalu besar, kompres mi dulu'); 
    //     </script>";
    //     return false;
    // }

    // move_uploaded_file($tmpname, 'img/' . $fileskhu);

    // return $fileskhu;



    // $jenisgambarvalid = ['jpg', 'jpeg'];
    // $jenisgambar = explode('.', $filefoto);
    // $ekstensi = strtolower(end($jenisgambar));
    // if(!in_array($ekstensi, $jenisgambarvalid)){
    //     echo "<script> alert('bukan gambar itu'); 
    //         </script>";
    //     return false;
    // }
    // if($ukuranfoto > 1000000) {
    //     echo "<script> alert('terlalu besar, kompres mi dulu'); 
    //     </script>";
    //     return false;
    // }

    // move_uploaded_file($tmpname, 'img/' . $filefoto);

    // return $filefoto;



    // $query = "INSERT INTO data_siswa
    //         VALUES ('$nisn', 
    //         '$nama', 
    //         '$tempat', 
    //         '$tanggal', 
    //         '$gender', 
    //         '$agama', 
    //         '$no_hp', 
    //         '$alamat', 
    //         '$ayah', 
    //         '$p_ayah', 
    //         '$ibu', 
    //         '$p_ibu', 
    //         '$sekolah', 
    //         '$fileraport', 
    //         '$fileskhu', 
    //         '$filefoto')";

    // mysqli_query($koneksi, $query);




    // if(mysqli_affected_rows($koneksi) > 0){
    //     echo "<script> alert('Berhasil menginput berkas');
    //                    document.location='form.php';
    //           </script>";
    // }else{
    //     echo "<script> alert('Input berkas gagal'); 
    //                    document.location='selesai.php';
    //          </script>";
    // }



   

    // $jenisgambarvalid = ['jpg', 'jpeg'];

    // $namafile = $_FILES['raport']['name'];
    // $namafile = $_FILES['skhu']['name'];
    // $namafile = $_FILES['foto']['name'];

    // $jenisgambar = explode('.', $namafile);
    // $ekstensi = strtoloer(end($jenisgambar));

    // $ukuranfile = $_FILES['raport']['size'];
    // $ukuranfile = $_FILES['skhu']['size'];
    // $ukuranfile = $_FILES['foto']['size'];

    // $tmpname = $_FILES['raport']['tmp_name'];
    // $tmpname = $_FILES['raport']['tmp_name'];
    // $tmpname = $_FILES['raport']['tmp_name'];

    // if(in_array($ekstensi, $jenisgambarvalid) === true){
    //     if($ukuranfile < 1044070){

    //     }else{
    //         echo "<script> alert('besarrr max.1mb'); document.location='form.php'
    //          </script>";
    //     }
    // }else{
    //     echo "<script> alert('nda boleh'); document.location='form.php'
    //          </script>";
    // }







}


?>