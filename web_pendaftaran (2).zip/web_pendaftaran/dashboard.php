<?php
include "koneksi.php";
$query = mysqli_query ($koneksi," SELECT * FROM data_siswa");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Dashboard</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="aset/logo.png" alt="logo" width="52" height="54">
                </a>
                <p class ="ketlog mt-1">SMP AL IRSYAD AL ISLAMIYYAH <br>GORONTALO</p>
                <div class="heading collapse navbar-collapse justify-content-center text-white">Dashboar Admin</div>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-wa" type="submit">Search</button>
                </form>
            </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="navver col-2 bg-success mt-5 ms-4 pe-3">
                <ul class="nav flex-column p-2">
                    <li class="nav-item">
                        <a class="nav-link text-white mt-5" href="dashboard.php">Dashboard</a>
                    </li>
                </ul>
            </div>

            <div class="pendaftar bg-success col mt-5">
                <h3 class="heading bg-success mt-5 me-4">Daftar pendaftar</h3>
                <div class="row"><table class="table">
                <thead>
                <table class="table table-striped">
                    <tr class="align-items-center justify-content-center">
                    <th scope="col">No</th>
                    <th scope="col">Nisn</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Tempat lahir</th>
                    <th scope="col">Tanggal lahir</th>
                    <th scope="col">Jenis kelamin</th>
                    <th scope="col">Agama</th>
                    <th scope="col">Nomor</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Ayah</th>
                    <th scope="col">pekerjaan ayah</th>
                    <th scope="col">Ibu</th>
                    <th scope="col">Pekerjaan ibu</th>
                    <th scope="col">asal sekolah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row_query = mysqli_fetch_array($query)):?>
                    <tr>
                    <th scope="row">1</th>
                    <td><?php echo "$row_query[nisn]";?></td>
                    <td><?php echo "$row_query[nama_lengkap]";?></td>
                    <td><?php echo "$row_query[tempat]";?></td>
                    <td><?php echo "$row_query[tanggal_lahir]";?></td>
                    <td><?php echo "$row_query[jenis_kelamin]";?></td>
                    <td><?php echo "$row_query[agama]";?></td>
                    <td><?php echo "$row_query[nomor_handphone]";?></td>
                    <td><?php echo "$row_query[alamat]";?></td>
                    <td><?php echo "$row_query[ayah]";?></td>
                    <td><?php echo "$row_query[pekerjaan_ayah]";?></td>
                    <td><?php echo "$row_query[ibu]";?></td>
                    <td><?php echo "$row_query[pekerjaan_ibu]";?></td>
                    <td><?php echo "$row_query[asal_sekolah]";?></td>
                    </tr>
                        <?php endwhile?>
                </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>

    
    
</body>
</html>