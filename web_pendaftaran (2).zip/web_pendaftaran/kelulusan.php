<?php
include "koneksi.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Boostrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <title>Menu</title>
</head>
<body>

    <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="aset/logo.png" alt="logo" width="52" height="54">
                </a>
                <p class ="ketlog mt-1">SMP AL IRSYAD AL ISLAMIYYAH <br>GORONTALO</p>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php">Login</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="menu.php">Menu Utama</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="form.php">Form</a>
                    </li>
                </ul>
                </div>
            </div>
    </nav>

    <div class="row d-flex justify-content-between">
        <div class="container mt-5">
                <h1 class="heading text-center my-5">Halo, Calon siswa baru 2023/2024 <br>SMP AL IRSYAD AL ISLAMIYYAH GORONTALO</h1>
            <div class="row d-flex justify-content-center mt-5 mx-1">
                <div class="col-lg-4 login-wrapper text-center rounded-3 p-3">
                    <h4>Maaf, kelulusan belum diumumkan. Silahkan datang kembali pada tanggal pengumuman yang telah ditentukan panitia</h4>
                <a href="menu.php" class="btn btn-login my-3">Kembali</a>
                </div>
            </div>
            
        </div>
        
</body>
</html>