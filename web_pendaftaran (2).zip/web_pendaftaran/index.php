<?php
include "koneksi.php";

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Custom CSS -->
        <link rel="stylesheet" href="css/style.css">
        <!-- Boostrap -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <!-- Box Icon -->
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    </head>

    <body>
        <!-- Login -->
        <div class="container l-wrapper">
            <div class="row fotonlogo d-flex justify-content-center">
                <div class="col-lg-4 d-flex justify-content-end p-3">
                    <img src="aset/logo.png" class="card-img-top" alt="logo">
                </div>
                <div class="col-lg-6 p-3">
                    <h2 class="heading mt-5">SMP AL IRSYAD AL ISLAMIYYAH <br>GORONTALO</h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row d-flex justify-content-center mt-5">
                <div class="col-lg-4 p-3 rounded-3 login-wrapper">
                    <form class="login " action="aksi_crud.php" method="POST">
                        <div class="col mb-3">
                            <label for="exampleInputEmail1" class="form-label" >Email</label>
                            <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  required>
                            <label for="exampleInputPassword1" class="form-label mt-2" >Password</label>
                            <input type="password" name="password" class="form-control" id="exampleInputPassword1"  required>
                            <input href="menu.php" type="submit" name="login" class="btn btn-login mt-3" >
                            </div>
                    </form>
                </div>
                <div class="pesan d-flex justify-content-center mt-1">
                    <p class="note">
                        Belum registrasi? silahkan hubungi nomor yang tertera dibawah ini
                    </p>
                </div>
            </div>
        </div>
        
        <div class="row mb-5">
            <div class="col-lg-2 position-absolute end-0 bottom-end mb-2">
                <a class="btn btn-wa" href="https://wa.me/6285346567483?text=Halo admin" role="button"><i class='bx bxl-whatsapp'></i>Admin</a>
            </div>
        </div>
</body>
</html>