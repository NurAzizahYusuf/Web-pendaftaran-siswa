<?php
include "koneksi.php";

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Custom CSS -->
        <link rel="stylesheet" href="css/style.css">
        <!-- Boostrap -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <!-- Box Icon -->
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    </head>

    <body>

    <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="aset/logo.png" alt="logo" width="52" height="54">
                </a>
                <p class ="ketlog mt-1">SMP AL IRSYAD AL ISLAMIYYAH <br>GORONTALO</p>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php">Login</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="menu.php">Menu</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="form.php">Form</a>
                    </li>
                </ul>
                </div>
            </div>
        </nav>    


        <div class="container mt-5">
            <div class="row d-flex justify-content-center mt-5">
                <h1 class="heading text-center my-5">Halo, Calon siswa baru 2023/2024 <br>SMP AL IRSYAD AL ISLAMIYYAH GORONTALO</h1>
                <div class="col-lg-3 login-wrapper rounded-3 p-3">
                    <p>Berkas telah berhasil di upload mohon tunggu info kelulusan yang akan dikirimkan pada nomor yang telah dikumpulkan.</p>
                </div>
            </div>
        </div>
        
</body>
</html>
 